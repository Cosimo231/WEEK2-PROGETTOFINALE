<?php
/**
 * @package     belinni
 * @version     1.1.5
 * @author      Pixelshow
 * @link        http://pixel-show.com
 * @copyright   Copyright (c) 2017 Pixelshow
 * @license     GPL v2
 
 Plugin Name: About Widget
 */

add_action( 'widgets_init', 'pixelshow_about_load_widget' );

function pixelshow_about_load_widget() {
	register_widget( 'pixelshow_about_widget' );
}

class pixelshow_about_widget extends WP_Widget {

	function __construct()
	{
		$widget_ops = array( 'classname' => 'pixelshow_about_widget', 'description' => esc_html__('A widget that displays an About widget', 'belinni') );
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'pixelshow_about_widget' );
		parent::__construct( 'pixelshow_about_widget', esc_html__('Belinni: About Me', 'belinni'), $widget_ops, $control_ops );
	}


	function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters('widget_title', $instance['title'] );
		$image = $instance['image'];
		$round = $instance['round'];
		$description = $instance['description'];
		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;
		?>
			<div class="about-widget">
			<?php if($image) : ?>
			<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_html($title); ?>" <?php if($round == true) : ?>class="about-round"<?php endif; ?>/>
			<?php endif; ?>
			<?php if($description) : ?>
			<div><?php echo wp_kses_post($description); ?></div>
			<?php endif; ?>	
			</div>
		<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['image'] = strip_tags( $new_instance['image'] );
		$instance['round'] = $new_instance['round'];
		$instance['description'] = $new_instance['description'];
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'title' => 'About Me', 'image' => '', 'round' => '1', 'description' => '');
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('title')); ?>"><?php echo esc_html( 'Title:', 'belinni' ); ?></label>
			<input id="<?php echo esc_html($this->get_field_id( 'title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" style="width:96%;" />
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'image' )); ?>"><?php echo esc_html( 'Image URL:', 'belinni' ); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'image' )); ?>" name="<?php echo esc_html($this->get_field_name( 'image' )); ?>" value="<?php echo esc_url($instance['image']); ?>" style="width:96%;" /><br />
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'round' )); ?>"><?php echo esc_html( 'Make image a circle:', 'belinni' ); ?></label>
			<input type="checkbox" id="<?php echo esc_html($this->get_field_id( 'round' )); ?>" name="<?php echo esc_html($this->get_field_name( 'round' )); ?>" value="round" <?php checked( (bool) $instance['round'], true );?> />
			<br><small><?php echo esc_html( 'For a perfect circle your image need to have the same height and width. For example: 260x260', 'belinni' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'description' )); ?>"><?php echo esc_html( 'About me text:', 'belinni' ); ?></label>
			<textarea id="<?php echo esc_html($this->get_field_id( 'description' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'description' )); ?>" style="width:95%;" rows="6"><?php echo esc_html($instance['description']); ?></textarea>
		</p>
	<?php
	}
}
?>