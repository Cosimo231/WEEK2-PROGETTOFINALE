<?php
/*
Plugin Name: Belinni Theme Addons
Plugin URI: https://themeforest.net/user/pixelshow
Description: Addons for admin panel and other extra theme features
Author: Pixelshow
Version: 1.0
Author URI: https://themeforest.net/user/pixelshow
Text Domain: belinni
License: General Public License
*/

/**
 * Author socials
 */
function pixelshow_contactmethods( $contactmethods ) {

	$contactmethods['twitter']   =  esc_html__( 'Twitter Username', 'belinni' );
	$contactmethods['facebook']  = esc_html__( 'Facebook Username', 'belinni' );
	$contactmethods['google']    = esc_html__( 'Google Plus Username', 'belinni' );
	$contactmethods['tumblr']    = esc_html__( 'Tumblr Username', 'belinni' );
	$contactmethods['instagram'] = esc_html__( 'Instagram Username', 'belinni' );
	$contactmethods['pinterest'] = esc_html__( 'Pinterest Username', 'belinni' );

	return $contactmethods;
}
add_filter('user_contactmethods','pixelshow_contactmethods');

// Widgets
require_once('widgets/about-widget.php');
require_once('widgets/social-widget.php');
require_once('widgets/post-widget.php');
require_once('widgets/sliderpost-widget.php');
require_once('widgets/facebook-widget.php');
require_once('widgets/tabs-widget.php');
require_once('widgets/flickr.php');
require_once('widgets/pinterest.php');

/**
 * Post-likes
 */
require_once('post-like.php');

/*Import content data*/
function ocdi_import_files() {
	return array(
		array(
			'import_file_name'             => 'Modern',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/modern/modern.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/modern/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/modern/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/modern.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/',
		),
		array(
			'import_file_name'             => 'Light & Minimal',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/minimal/minimal.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/minimal/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/minimal/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/minimal.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/light-minimal/',
		),
		array(
			'import_file_name'             => 'Home & Decor',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/home/home.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/home/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/home/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/home.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/home-decor/',
		),
		array(
			'import_file_name'             => 'Lifestyle',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/lifestyle/lifestyle.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/lifestyle/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/lifestyle/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/lifestyle.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/lifestyle/',
		),
		array(
			'import_file_name'             => 'Food',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/food/food.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/food/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/food/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/food.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/food/',
		),
		array(
			'import_file_name'             => 'Fashion',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/fashion/fashion.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/fashion/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/fashion/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/fashion.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/fashion/',
		),
		array(
			'import_file_name'             => 'Travel',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/travel/travel.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/travel/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/travel/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/travel.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/travel/',
		),
		array(
			'import_file_name'             => 'Personal',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/personal/personal.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/personal/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/personal/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/personal.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/personal/',
		),
		array(
			'import_file_name'             => 'Photography',
			'local_import_file'            => trailingslashit( get_template_directory() ) . '/demo-import/photography/photography.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . '/demo-import/photography/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/demo-import/photography/customizer.dat',
			'import_preview_image_url'     => 'http://pixel-show.com/tf-images/import-images/belinni/photo.png',
			'import_notice'                => __( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'belinni' ),
			'preview_url'                  => 'http://belinni.pixel-show.com/photography/',
		)
	);
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );

function pxswork_after_import() {

	$top_menu = get_term_by('name', 'Menu', 'nav_menu');
	set_theme_mod( 'nav_menu_locations', array(
		'primary-menu' => $top_menu->term_id,
	));


}
add_action( 'pt-ocdi/after_import', 'pxswork_after_import' );
